package br.com.seteu.criandoapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CriandoapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CriandoapiApplication.class, args);
	}

}
