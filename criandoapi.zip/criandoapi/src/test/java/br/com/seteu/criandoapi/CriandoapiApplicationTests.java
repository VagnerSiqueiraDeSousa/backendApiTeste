package br.com.seteu.criandoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CriandoapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
